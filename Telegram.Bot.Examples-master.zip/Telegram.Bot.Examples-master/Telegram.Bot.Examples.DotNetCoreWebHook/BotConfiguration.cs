namespace Telegram.Bot.Examples.DotNetCoreWebHook
{
    public class BotConfiguration
    {
        public string BotToken { get; set; }

        public string Socks5Host { get; set; }

        public int Socks5Port { get; set; }
    }
}
